% Plank Function
function B = B(tau,S_0)
    B = (S_0/2).*tau + S_0/2;
end
