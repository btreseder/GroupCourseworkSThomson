% Analytical Solution of Upward Flux
function U = U(tau,S_0)
    U = S_0+(S_0/2).*tau;
end
