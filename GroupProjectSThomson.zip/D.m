% Analytical Solution of Downward Flux
function D = D(tau,S_0)
    D = (S_0.*tau)/2;
end
